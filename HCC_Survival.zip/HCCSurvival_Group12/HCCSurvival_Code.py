# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 20:19:25 2021

DS 6100 Project
HCC Survival - Group 12
Ana Daley, Elizabeth Lee, Avni Malik
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import unittest

# Create Classes for Data Exploration and Conversion
class computePct():
    '''Takes input of a data frame series and calculates the percent null, percent true (ie 1), and percent false (ie 0)'''
    
    def __init__(self, series):
        self.series = series
        self.null_count = 'NA'
        self.true_count = 'NA'
        self.false_count = 'NA'
        
    def pctNull(self):
        tot_count = len(self.series)
        self.null_count = self.series.isna().sum()
        self.pct_null = 100 * self.null_count / tot_count
        return self.pct_null
    
    def pctTrue(self):
        self.true_count = 0
        tot_count = len(self.series)
        for i in self.series:
            if i == '1':
                self.true_count += 1
        self.pct_true = 100 * self.true_count / tot_count
        return self.pct_true
    
    def pctFalse(self):
        self.false_count = 0
        tot_count = len(self.series)
        for i in self.series:
            if i == '0':
                self.false_count += 1
        self.pct_false = 100 * self.false_count / tot_count
        return self.pct_false

# Creating a class that parses columns within a data frame to desired variable type
class createList():
    '''Takes a data frame series and outputs a list of ints, floats or strings'''
    
    def __init__(self, series):
        self.series = series
        
    def toInt(self):
        self.Int_arr = [int(i) for i in self.series]
        return self.Int_arr
    
    def toFloat(self):
        self.Float_arr = [float(i) for i in self.series]
        return self.Float_arr
    
    def toStr(self):
        self.Str_arr = [str(i) for i in self.series]
        return self.Str_arr
    
# Creating a class that creates desired type of graph (including all labels)
class createGraph:
    '''Takes input of two lists and graph labels and outputs plots'''
    
    def __init__(self, x, y, x_label, y_label):
        self.X_arr = x
        self.Y_arr = y
        self.x_label = x_label
        self.y_label = y_label
    
    def makeScatter(self):
        self.fig = plt.scatter(x = self.X_arr, y = self.Y_arr)
        plt.xlabel(self.x_label)
        plt.ylabel(self.y_label)
        plt.title('Scatter Plot of ' + self.y_label + ' on ' + self.x_label)
        return self.fig    
    
    def makeBoxplot(self):
        self. fig = sns.boxplot(x = self.X_arr, y = self.Y_arr)
        plt.xlabel(self.x_label)
        plt.ylabel(self.y_label)
        plt.title('Boxplot of ' + self.y_label + ' on ' + self.x_label)

# Develop Unit Test Suite
class computePCTTestCase(unittest.TestCase):
    
    x = pd.Series(['1', '1', '0', '0', '1', '1', None, None, '1', '0'])
    pcts = computePct(x)
    
    def test_1_pctNull(self):
        self.pcts.pctNull()
        expected = 20
        
        self.assertEqual(self.pcts.pct_null, expected)
        
    def test_2_pctTrue(self):
        self.pcts.pctTrue()
        expected = 50
        
        self.assertEqual(self.pcts.pct_true, expected)
        
    def test_3_pctFalse(self):
        self.pcts.pctFalse()
        expected = 30
        
        self.assertEqual(self.pcts.pct_false, expected)
        
class CreateListTestCase(unittest.TestCase):
    
    def test_1_toInt(self):
        list_str = ['0','1','2','3','4','5','6','7','8','9']
        list1 = createList(list_str)
        list1 = list1.toInt()
        
        for i in list1:
            self.assertIsInstance(i, int)
            
    def test_2_toFloat(self):
        list_str = ['0','1','2','3','4','5','6','7','8','9']
        list2 = createList(list_str)
        list2 = list2.toFloat()
        
        for i in list2:
            self.assertIsInstance(i, float)
            
    def test_3_toStr(self):
        list_int = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        list3 = createList(list_int)
        list3 = list3.toStr()
        
        for i in list3:
            self.assertIsInstance(i, str)
         
if __name__ == '__main__':
    unittest.main()  

# Read in data and create data frame    
col_names = ['Gender','Symptoms','Alcohol','Hep B Surface Antigen','Hep B e Anitgen','Hep B Core Antibody',
             'Hep C Virus Antibody','Cirrhosis','Endemic','Smoking','Diabetes','Obesity','Hemochromatosis',
             'Arterial Hypertension','Chronic Renal Insufficiency','HIV','Nonalcoholic Steatohepatitis: nominal',
             'Esophageal Varices', 'Splenomegaly', 'Portal Hypertension', 'Portal Vein Thrombosis', 'Liver Metastasis', 
             'Radiological Hallmark', 'Age at diagnosis', 'Grams of Alcohol', 'Packs of cigarets per year', 'Performance Status',
             'Encefalopathy degree', 'Ascites degree', 'International Normalised Ratio', 'Alpha-Fetoprotein (ng/mL)', 'Haemoglobin (g/dL)', 
             'Mean Corpuscular Volume (fl)', 'Leukocytes(G/L)', 'Platelets (G/L)', 'Albumin (mg/dL)', 'Total Bilirubin(mg/dL)', 
             'Alanine transaminase (U/L)', 'Aspartate transaminase (U/L)', 'Gamma glutamyl transferase (U/L)', 'Alkaline phosphatase (U/L)', 
             'Total Proteins (g/dL)', 'Creatinine (mg/dL)', 'Number of Nodules', 'Major dimension of nodule (cm)', 'Direct Bilirubin (mg/dL)',
             'Iron (mcg/dL)', 'Oxygen Saturation (%)', 'Ferritin (ng/mL)', 'Class']

HCC_df = pd.read_csv('hcc-data.txt', header = None)
HCC_df.columns = col_names
HCC_df = HCC_df.replace('?', np.nan)

print(HCC_df.head())

print(HCC_df.info())

# Determine Percent Null of Each Column
Null_Pct = {}
for i in col_names:
    c_pct = computePct(HCC_df[i])
    n_pct = c_pct.pctNull()
    Null_Pct[i] = n_pct

Null_df = pd.DataFrame.from_dict(Null_Pct, orient = 'index')
Null_df.columns = ['Percent Null']
print(Null_df)

# Nodule Dimension to Class
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Class = createList(HCC_df['Class'])
Class = Class.toInt()
x_name = 'Class'
y_name = 'Major Dim of Nodule (cm)'

g1 = createGraph(Class, Nod_Dims, x_name, y_name)
g1.makeBoxplot()

# Number of Nodules to Grams of Alcohol
Nod_Num = createList(HCC_df['Number of Nodules'])
Nod_Num = Nod_Num.toFloat()
Grams_Alc = createList(HCC_df['Grams of Alcohol'])
Grams_Alc = Grams_Alc.toFloat()
x_name = 'Number of Nodules'
y_name = 'Grams of Alcohol'

g2 = createGraph(Nod_Num, Grams_Alc, x_name, y_name)
g2.makeBoxplot()

# Nodule Dimension to Grams of Alcohol
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Grams_Alc = createList(HCC_df['Grams of Alcohol'])
Grams_Alc = Grams_Alc.toFloat()
x_name = 'Major Dimension of Nodule (cm)'
y_name = 'Grams of Alcohol'

g3 = createGraph(Nod_Dims, Grams_Alc, x_name, y_name)
g3.makeScatter()

# Leukocytes to Nodule Dimensions
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Leuko = createList(HCC_df['Leukocytes(G/L)'])
Leuko = Leuko.toFloat()
x_name = 'Major Dimension of Nodule (cm)'
y_name = 'Leukocytes(G/L)'

g4 = createGraph(Nod_Dims, Leuko, x_name, y_name)
g4.makeScatter()

# Leukocytes to Number of Nodules
Nod_Num = createList(HCC_df['Number of Nodules'])
Nod_Num = Nod_Num.toFloat()
Leuko = createList(HCC_df['Leukocytes(G/L)'])
Leuko = Leuko.toFloat()
x_name = 'Number of Nodules'
y_name = 'Leukocytes(G/L)'

g5 = createGraph(Nod_Num, Leuko, x_name, y_name)
g5.makeBoxplot()

# Leukocytes to Class
Class = createList(HCC_df['Class'])
Class = Class.toInt()
Leuko = createList(HCC_df['Leukocytes(G/L)'])
Leuko = Leuko.toFloat()
x_name = 'Class'
y_name = 'Leukocytes(G/L)'

g6 = createGraph(Class, Leuko, x_name, y_name)
g6.makeBoxplot()

# Nodule Dimension to PVT
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
PVT = createList(HCC_df['Portal Vein Thrombosis'])
PVT = PVT.toFloat()
x_name = 'Portal Vein Thrombosis'
y_name = 'Major Dimension of Nodule (cm)'

g7 = createGraph(PVT, Nod_Dims, x_name, y_name)
g7.makeBoxplot()

# Number of Nodules to PVT
Nod_Num = createList(HCC_df['Number of Nodules'])
Nod_Num = Nod_Num.toFloat()
PVT = createList(HCC_df['Portal Vein Thrombosis'])
PVT = PVT.toFloat()
x_name = 'Portal Vein Thrombosis'
y_name = 'Number of Nodules'

g8 = createGraph(PVT, Nod_Num, x_name, y_name)
g8.makeBoxplot()

# Nodule Dimension to Age
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Age = createList(HCC_df['Age at diagnosis'])
Age = Age.toFloat()
x_name = 'Age'
y_name = 'Major Dimension of Nodule (cm)'

g9 = createGraph(Age, Nod_Dims, x_name, y_name)
g9.makeScatter()

# Nodule Dimension to Smoking
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Smoke = createList(HCC_df['Smoking'])
Smoke = Smoke.toFloat()
x_name = 'Smoking'
y_name = 'Major Dimension of Nodule (cm)'

g10 = createGraph(Smoke, Nod_Dims, x_name, y_name)
g10.makeBoxplot()

# Nodule Dimension to Iron
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Iron = createList(HCC_df['Iron (mcg/dL)'])
Iron = Iron.toFloat()
x_name = 'Iron (mcg/dL)'
y_name = 'Major Dimension of Nodule'

g11 = createGraph(Iron, Nod_Dims, x_name, y_name)
g11.makeScatter()

# Major Dimension of Nodule to Cirrhosis 
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Cirrhosis = createList(HCC_df['Cirrhosis'])
Cirrhosis = Cirrhosis.toFloat()
x_name = 'Cirrhosis (mcg/dL)'
y_name = 'Major Dimension of Nodule'

g12 = createGraph(Cirrhosis, Nod_Dims, x_name, y_name)
g12.makeBoxplot()

# Major Dimension of Nodule to ALbumin
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Albumin = createList(HCC_df['Albumin (mg/dL)'])
Albumin = Albumin.toFloat()
x_name = 'Albumin (mg/dL)'
y_name = 'Major Dimension of Nodule'

g13 = createGraph(Albumin, Nod_Dims, x_name, y_name)
g13.makeScatter()

# Major Dimension of Nodule to Bilirubin
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Bilirubin = createList(HCC_df['Total Bilirubin(mg/dL)'])
Bilirubin = Bilirubin.toFloat()
x_name = 'Total Bilirubin(mg/dL)'
y_name = 'Major Dimension of Nodule'

g14 = createGraph(Bilirubin, Nod_Dims, x_name, y_name)
g14.makeScatter()

# Major Dimension of Nodule to INR
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
INR = createList(HCC_df['International Normalised Ratio'])
INR = INR.toFloat()
x_name = 'International Normalised Ratio'
y_name = 'Major Dimension of Nodule'

g15 = createGraph(INR, Nod_Dims, x_name, y_name)
g15.makeScatter()

# Major Dimension of Nodule to Encefalopathy
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Enc = createList(HCC_df['Encefalopathy degree'])
Enc = Enc.toFloat()
x_name = 'Encefalopathy Degree'
y_name = 'Major Dimension of Nodule'

g16 = createGraph(Enc, Nod_Dims, x_name, y_name)
g16.makeBoxplot()

# Major Dimension of Nodule to Ascites
Nod_Dims = createList(HCC_df['Major dimension of nodule (cm)'])
Nod_Dims = Nod_Dims.toFloat()
Asc = createList(HCC_df['Ascites degree'])
Asc = Asc.toFloat()
x_name = 'Ascites Degree'
y_name = 'Major Dimension of Nodule'

g17 = createGraph(Asc, Nod_Dims, x_name, y_name)
g17.makeBoxplot()
